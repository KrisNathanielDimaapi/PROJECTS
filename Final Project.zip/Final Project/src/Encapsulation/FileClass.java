package Encapsulation;

import java.util.ArrayList;
import java.util.*;
import java.time.format.*;
import java.time.*;
import java.io.*;
import java.nio.charset.Charset;
import java.nio.file.*;

public class FileClass {
    static ArrayList<String> overall;
    static Scanner input_user;
    static DateTimeFormatter dateTime = DateTimeFormatter.ofPattern("yyyy/MM/dd hh:mm:ss a", Locale.getDefault());

    // INSERT FILE METHOD
    static public void insert_file() {
        String dateTime = getTimestamp();

        System.out.println();
        System.out.print("\nEnter a message: ");
        String note = input_user.nextLine();

        overall.add(note + " / " + dateTime);

        MessageFile();
        System.out.println("\nMessage has been inserted.");
    }

    // DELETE FILE METHOD
    static public void delete_file() {
        System.out.print("\nSelect Message to delete(Enter number): ");
        try {
            int search = input_user.nextInt();
            input_user.nextLine();
            int index = overall.indexOf(overall.get(search - 1));
            System.out.println();
            if (index != -1) {
                System.out.println(" " + (index + 1) + ")" + ". " + overall.get(search - 1));
                System.out.print("\nDo you want to delete this message? Press [1] if YES or [2] is NO: ");
                int delDecision = input_user.next().charAt(0);
                if (delDecision == '1') {
                    overall.remove(index);
                    System.out.println("\nThe message has been deleted!");
                    System.out.println();
                } else if (delDecision == '2') {
                    System.out.println("\nThe message was not deleted!");
                } else {
                    System.out.println("\nInvalid input! Please try again\n");
                }
            } else {
                System.out.println(search + " is not found in the collection!\n");
            }
        } catch (IndexOutOfBoundsException e) {
            System.out.println("\nThe message you have entered is invalid! Please try again!\n");
        }
        MessageFile();
    }

    // DISPLAY METHOD
    static public void display_file() {
        if (overall.size() > 0) {
            int counter = 0;
            for (String message : overall) {
                System.out.printf("%d). %s%n", ++counter, message);
            }
        } else {
            System.out.println("\n  Theres no message displayed.\n");
        }
    }

    // SEARCH FILE METHOD
    static public void search_file() {
        System.out.print("\nEnter a number of the Message: ");
        try {
            int search = input_user.nextInt();
            input_user.nextLine();
            System.out.println("\nSearch result:");
            int index = overall.indexOf(overall.get(search - 1));
            if (index != -1) {
                System.out.println(" " + (index + 1) + ")" + ". " + overall.get(search - 1));
            } else {
                System.out.println("\nThe message of the number" + search + " is not found in the collection!");
            }
        } catch (IndexOutOfBoundsException e) {
            System.out.println("\nThe number you have entered is invalid! Please try again.");
        }
    }

    // UPDATE FILE METHOD
    static public void update_file() {
        String dateTime = getTimestamp();
        System.out.print("\nEnter a number of message to update: ");
        try {
            int search = input_user.nextInt();
            int index = overall.indexOf(overall.get(search - 1));
            String updateLine;
            if (index != -1) {
                System.out.println("\nCurrent Message: ");
                System.out.println(" " + (index + 1) + ")" + ". " + overall.get(search - 1));
                System.out.print("\nThe updated message will be: ");
                input_user.nextLine();
                updateLine = input_user.nextLine();
                overall.set(index, updateLine + " /" + dateTime);
                System.out.print("\nThe message has been updated!\n");
            } else {
                System.out.println(search + " is not found in the collection!");
            }
        } catch (IndexOutOfBoundsException e) {
            System.out.println("\nThe number you have entered is invalid! Please try again.");
        }
        MessageFile();
    }

    // DATE AND TIME
    static private String getTimestamp() {
        LocalDate todayDate = LocalDate.now();
        LocalTime nowTime = LocalTime.now();
        String timeFormat = nowTime.format(DateTimeFormatter.ofLocalizedTime(FormatStyle.MEDIUM));
        String dateTime = todayDate.toString() + " at " + timeFormat;// ZonedDateTime.now(ZoneId.systemDefault()).format(dateTimeObj);
        return dateTime;
    }

    private void file() throws IOException {
        Path path = Paths.get("MESSAGEFILE.txt");
        if (Files.isRegularFile(path)) {
            overall.addAll(Files.readAllLines(path, Charset.defaultCharset()));
        }
    }

    public FileClass() throws IOException {
        input_user = new Scanner(System.in);
        overall = new ArrayList<String>();
        file();
    }

    // MESSAGE FILE METHOD
    static public void MessageFile() {
        Path path = Paths.get("MESSAGEFILE.txt");
        try (BufferedWriter bw = Files.newBufferedWriter(path,
                StandardOpenOption.CREATE,
                StandardOpenOption.WRITE);
                PrintWriter pw = new PrintWriter(bw)) {
            for (String write : overall) {
                pw.println(write);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void showMenu() {
        while (true) {
            System.out.println("====================================");
            System.out.println("\n     WELCOME TO FILE HANDLING\n");
            System.out.println("====================================");
            System.out.println("\t    [1] INSERT");
            System.out.println("\t    [2] DELETE");
            System.out.println("\t    [3] DISPLAY");
            System.out.println("\t    [4] SEARCH");
            System.out.println("\t    [5] UPDATE");
            System.out.println("\t    [6] EXIT");
            try {
                // User Choices
                System.out.println();
                System.out.print("\tENTER YOUR CHOICE: ");
                int choice = input_user.nextInt();
                input_user.nextLine();
                switch (choice) {
                    case 1:
                        FileClass.insert_file();
                        break;

                    case 2:
                        FileClass.delete_file();
                        break;

                    case 3:
                        FileClass.display_file();
                        break;

                    case 4:
                        FileClass.search_file();
                        break;

                    case 5:
                        FileClass.update_file();
                        break;
                    case 6:
                        System.exit(0);
                        break;

                    default:
                        System.out.println("\nINVALID CHOICE! Please try again.\n");
                        break;
                }
            } catch (InputMismatchException e) {
                System.out.println("\n\t  Invalid Input");
                System.out.println("\nPress ENTER to go back to Main Menu\n");
                input_user.nextLine();
            }
        }
    }
}
