import Encapsulation.FileClass;

import java.io.IOException;

public class Main {
    public static void main(String[] args) throws IOException {
        try {
            FileClass file = new FileClass();
            file.showMenu();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}
